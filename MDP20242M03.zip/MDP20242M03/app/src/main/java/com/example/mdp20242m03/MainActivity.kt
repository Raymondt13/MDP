package com.example.mdp20242m03

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.mdp20242m03.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

//        setContentView(R.layout.activity_main)

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.constraint_main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // snake_case
        // camelCase
        // TitleCase
        // kebab-case
        // SCREAMING_SNAKE_CASE

        binding.processBtnMain.setOnClickListener {
            val name = binding.nameEtMain.text.toString()
            val age = binding.ageEtMain.text.toString().toInt()
            val hobbies = ArrayList<String>()
            if(binding.crochetingCbMain.isChecked){
                hobbies.add("Crocheting")
            }
            if(binding.drawingCbMain.isChecked){
                hobbies.add("Drawing")
            }
            if(binding.origamiCbMain.isChecked){
                hobbies.add("Origami")
            }
            val gender = if(binding.maleRbMain.isChecked){
                "Male"
            }
            else if(binding.femaleRbMain.isChecked){
                "Female"
            }
            else{
                "Other"
            }
            val major = binding.majorSpinnerMain.selectedItem.toString()
            Toast.makeText(this, "$name, $age, $hobbies, $gender, $major", Toast.LENGTH_SHORT).show()
            Log.d("debug", "$name, $age, $hobbies, $gender, $major")

            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

        binding.dialIbMain.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:08123456789"))
            startActivity(intent)
        }

        binding.alarmIbMain.setOnClickListener {
//            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
//            intent.putExtra(AlarmClock.EXTRA_MESSAGE, "BANGUN WOI")
//            intent.putExtra(AlarmClock.EXTRA_HOUR, 18)
//            intent.putExtra(AlarmClock.EXTRA_MINUTES, 0)

            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "BANGUN WOI")
                putExtra(AlarmClock.EXTRA_HOUR, 18)
                putExtra(AlarmClock.EXTRA_MINUTES, 0)
            }
            startActivity(intent)
        }

//        val items = listOf("aaa", "bbb", "ccc")
//        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
//        binding.majorSpinnerMain.adapter = adapter

//        val nameEt:EditText = findViewById(R.id.name_et_main)
//        val ageEt:EditText = findViewById(R.id.age_et_main)
//        val resultTv:TextView = findViewById(R.id.result_tv_main)
//        val processBtn:Button = findViewById(R.id.process_btn_main)
//
//        ageEt.setText("0")
//
//        processBtn.setOnClickListener {
//            val name = nameEt.text.toString()
////            resultTv.text = name
//            resultTv.setText(name)
//
//            val age = ageEt.text.toString().toInt()
////            resultTv.text = age.toString()
//            resultTv.setText(age.toString())
//
//        }
    }
}